# Automatic build
Built website from `4a2c813`. See https://github.com/ethereum/browser-solidity/ for details.
To use an offline copy, download `remix-4a2c813.zip`.
